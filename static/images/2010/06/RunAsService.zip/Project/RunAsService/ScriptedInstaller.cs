using log4net;

using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration.Install;
using System.Collections.Specialized;
using System.ServiceProcess;
using Microsoft.Win32;

namespace nl.dulsoft.windows.service.installer
{
	/// <summary>
	/// This is a custom service installer.
	/// Makes it possible to install the service using the .Net SDK supplied 
	/// installutil application.
	/// </summary>
	[RunInstaller(true)]
	public class ScriptedInstaller : Installer
	{
		private static ILog log = LogManager.GetLogger(typeof(ScriptedInstaller));
		private ServiceInstaller serviceInstaller = null;
		private ServiceProcessInstaller processInstaller = null;

		/// <summary>
		/// Initializes the installer
		/// </summary>
		public ScriptedInstaller()
		{
			if (!LogManager.GetRepository().Configured)
			{
				System.IO.FileInfo configFile = new System.IO.FileInfo("RunAsService.exe.log4net");
				if (configFile.Exists)
				{
					log4net.Config.XmlConfigurator.Configure(configFile);
				}
			}
			if (log.IsDebugEnabled) 
			{
				log.Debug("+cons");
			}

			processInstaller = new ServiceProcessInstaller();
			serviceInstaller = new ServiceInstaller();

			processInstaller.Account = System.ServiceProcess.ServiceAccount.User;
			serviceInstaller.StartType = ServiceStartMode.Automatic;
			serviceInstaller.ServiceName = "RunAsService";

			Installers.Add(serviceInstaller);
			Installers.Add(processInstaller);

			if (log.IsDebugEnabled) 
			{
				log.Debug("-cons");
			}
		}

		#region Access parameters
		/// <summary>
		/// Returns the value of th eparameter indicated by key.
		/// </summary>
		/// <param name="key">Context parameter key</param>
		/// <returns>Context parameter specified by key</returns>
		public string GetContextParameter(string key)
		{
			if (log.IsDebugEnabled)
			{
				log.Debug("+GetContextParameter(" + key + ")");
			}

			string result = "";
			try
			{
				result = Context.Parameters[key].ToString();
			}
			catch
			{
				if (log.IsWarnEnabled)
				{
					log.Warn("#Context parameter not found:" + key);
				}
			}

			if (log.IsDebugEnabled)
			{
				log.Debug("-GetContextParameter:" + result);
			}

			return result;
		}
		#endregion

		/// <summary>
		/// This method is run before the install process.
		/// It is overriden to set the following parameters:
		/// - service name taken from the /name switch
		/// - account type, taken frm the /account switch
		/// - user name, for a user account, taken from the /user switch
		/// - password, for a user account, taken from the /password switch
		/// 
		/// If the account type is set to user, but the user name and/or 
		/// password are not set, the user is prompted for the credentials 
		/// to use.
		/// </summary>
		/// <param name="savedState"></param>
		protected override void OnBeforeInstall(IDictionary savedState)
		{
			if (log.IsDebugEnabled)
			{
				log.Debug("+OnBeforeInstall(" + savedState.ToString() + ")");
			}

			base.OnBeforeInstall(savedState);
			bool isUserAccount = false;

			string name = GetContextParameter("name");
			serviceInstaller.ServiceName = name;

			string account = GetContextParameter("account");
			switch (account)
			{
				case "user":
					processInstaller.Account = ServiceAccount.User;
					isUserAccount = true;
					break;
				case "localservice":
					processInstaller.Account = ServiceAccount.LocalService;
					break;
				case "localsystem":
					processInstaller.Account = ServiceAccount.LocalSystem;
					break;
				case "networkservice":
					processInstaller.Account = ServiceAccount.NetworkService;
					break;
				default:
					processInstaller.Account = ServiceAccount.User;
					isUserAccount = true;
					break;
			}

			if (isUserAccount)
			{
				string userName = GetContextParameter("user");
				processInstaller.Username = userName;

				string password = GetContextParameter("password");
				processInstaller.Password = password;
			}

			if (log.IsDebugEnabled)
			{
				log.Debug("-OnBeforeInstall");
			}
		}


		/// <summary>
		/// Modify the registry to install the new service.
		/// </summary>
		/// <param name="stateServer"></param>
		public override void Install(IDictionary stateServer)
		{
			if (log.IsDebugEnabled)
			{
				log.Debug("+install(" + stateServer + ")");
			}

			base.Install(stateServer);

			RegistryKey system = Registry.LocalMachine.OpenSubKey("System");
			RegistryKey currentControlSet = system.OpenSubKey("CurrentControlSet");
			RegistryKey services = currentControlSet.OpenSubKey("Services");
			RegistryKey service = services.OpenSubKey(serviceInstaller.ServiceName, true);

			service.SetValue("Description", "Runs console applications as windows service");

			string imagePath = (string)service.GetValue("ImagePath");
			log.Info("ImagePath: " + imagePath);

			imagePath += " -s" + this.serviceInstaller.ServiceName;
			service.SetValue("ImagePath", imagePath);
			RegistryKey config = service.CreateSubKey("Parameters");
			
			config.Close();
			service.Close();
			services.Close();
			currentControlSet.Close();
			system.Close();

			if (log.IsDebugEnabled)
			{
				log.Debug("-install");
			}
		}

		/// <summary>
		/// Uninstall based on the services name.
		/// </summary>
		/// <param name="stateServer"></param>
		protected override void OnBeforeUninstall(IDictionary stateServer)
		{
			if (log.IsDebugEnabled)
			{
				log.Debug("+OnBeforeUninstall(" + stateServer + ")");
			}

			base.OnBeforeUninstall(stateServer);
			serviceInstaller.ServiceName = GetContextParameter("name");

			if (log.IsDebugEnabled)
			{
				log.Debug("-OnBeforeUninstall");
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="stateServer"></param>
		public override void Uninstall(IDictionary stateServer)
		{
			if (log.IsDebugEnabled)
			{
				log.Debug("+Uninstall(" + stateServer + ")");
			}

			base.Uninstall(stateServer);

			RegistryKey system = Registry.LocalMachine.OpenSubKey("System");
			RegistryKey currentControlSet = system.OpenSubKey("CurrentControlSet");
			RegistryKey services = currentControlSet.OpenSubKey("Services");
			RegistryKey service = services.OpenSubKey(serviceInstaller.ServiceName, true);

			if (null != service)
			{
				service.DeleteSubKeyTree("Parameters");
				service.Close();
			}
			
			services.Close();
			currentControlSet.Close();
			system.Close();

			if (log.IsDebugEnabled)
			{
				log.Debug("-Uninstall");
			}
		}
	}
}
