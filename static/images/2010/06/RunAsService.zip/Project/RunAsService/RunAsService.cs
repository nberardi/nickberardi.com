/*
 * RunAsService, the service to run non-service applications as a service
 *
 * Distributable under Academic Free License Version 1.2
 * See http://www.opensource.org/licenses/academic.php
 */

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.ServiceProcess;

using log4net;

using nl.dulsoft.windows.service.config;

namespace nl.dulsoft.windows.service
{
	/// <summary>
	/// Main class for running multiple applications as a windows service.
	/// </summary>
	public class RunAsService : System.ServiceProcess.ServiceBase
	{
		/// <summary>
		/// class level Log4Net logger
		/// </summary>
		private static readonly ILog log = LogManager.GetLogger(typeof(RunAsService));

		/// <summary>
		/// Creates an array of services to run, and runs each service in the array.
		/// </summary>
		static void Main()
		{
			if (log.IsDebugEnabled) 
			{
				log.Debug("+Main");
			}

			ServicesConfig config = ServicesConfig.getConfig();

			if (null == config) 
			{
				if (log.IsInfoEnabled)
				{
					log.Warn("No services defined. Exiting...");
				}

				return;
			}

			System.ServiceProcess.ServiceBase[] ServicesToRun = new ServiceBase[config.Count];
			int index = 0;

			foreach (Service service in config)
			{
				ServicesToRun[index] = new RunAsService(service);
				++index;
			}

			System.ServiceProcess.ServiceBase.Run(ServicesToRun);

			if (log.IsDebugEnabled) 
			{
				log.Debug("-Main");
			}
		}

		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private Service theService = null;

		/// <summary>
		/// Construct the event log if it does not exist
		/// </summary>
		/// <param name="aService">
		/// Properties of the application that is run as a service.
		/// </param>
		public RunAsService(Service aService)
		{
			if (log.IsDebugEnabled) 
			{
				log.Debug("+cons");
			}

			// This call is required by the Windows.Forms Component Designer.
			InitializeComponent();

			// Initialize the service info
			theService = aService;

			if (log.IsDebugEnabled)
			{
				log.Debug("-cons");
			}
		}

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// RunAsService
			// 
			this.ServiceName = "RunAsService";
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing"></param>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// Starts the application that needs to be run as service.
		/// </summary>
		protected override void OnStart(string[] args)
		{
			if (log.IsDebugEnabled)
			{
				log.Debug("+OnStart");
			}

			theService.start();

			if (log.IsInfoEnabled)
			{
				log.Info("Started " + theService);
			}

			if (log.IsDebugEnabled)
			{
				log.Debug("-OnStart");
			}
		}
 
		/// <summary>
		/// Stop this service.
		/// </summary>
		protected override void OnStop()
		{
			if (log.IsDebugEnabled)
			{
				log.Debug("+OnStop");
			}

			theService.stop();

			if (log.IsInfoEnabled)
			{
				log.Info("Stopped " + theService);
			}

			if (log.IsDebugEnabled)
			{
				log.Debug("-OnStop");
			}
		}
	}
}
