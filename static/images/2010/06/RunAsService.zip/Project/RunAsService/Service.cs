/*
 * RunAsService, the service to run non-service applications as a service
 *
 * Distributable under Academic Free License Version 1.2
 * See http://www.opensource.org/licenses/academic.php
 */

using System;
using System.Diagnostics;

using log4net;

namespace nl.dulsoft.windows.service
{
	/// <summary>
	/// Describes the properties of an application that needs to be run as a service.
	/// </summary>
	public class Service
	{
		private static ILog log = LogManager.GetLogger(typeof(Service));

		private string name = null;
		private string executable = null;
		private string parameterList = null;
		private Process process = null;

		/// <summary>
		/// Constructs a Service object.
		/// </summary>
		/// <param name="aName">Descriptive name of the service</param>
		/// <param name="anExecutable">Fullpath to the executable that is run as service</param>
		/// <param name="aParamList">List of commandline parameters</param>
		public Service(string aName, string anExecutable, string aParamList)
		{
			if (log.IsDebugEnabled)
			{
				log.Debug("+cons");
			}

			name = aName;
			executable = anExecutable;
			parameterList = aParamList;

			if (log.IsDebugEnabled)
			{
				log.Debug("-cons");
			}
		}

		/// <summary>
		/// Starts the service without a window
		/// </summary>
		public void start()
		{
			if (log.IsDebugEnabled)
			{
				log.Debug("+start:" + name);
			}

			ProcessStartInfo startInfo = new ProcessStartInfo();
			startInfo.FileName = executable;
			startInfo.Arguments = parameterList;
			startInfo.WindowStyle = ProcessWindowStyle.Hidden;

			process = new Process();
			process.StartInfo = startInfo;

			try 
			{
				process.Start();
			} 
			catch (System.ComponentModel.Win32Exception e)
			{
				log.Error("Unable to start service " + this, e);
				process = null;
			}

			if (log.IsDebugEnabled)
			{
				log.Debug("-start");
			}
		}

		/// <summary>
		/// Stops the service and destroy's the associated process.
		/// </summary>
		public void stop()
		{
			if (log.IsDebugEnabled)
			{
				log.Debug("+stop");
			}

			if (null != process)
			{
				process.CloseMainWindow();
				process.Close();
			}
			else
			{
				log.Error("Service " + name + " is not started");
			}

			if (log.IsDebugEnabled)
			{
				log.Debug("-stop");
			}
		}

		/// <summary>
		/// Constructs a concatenation of th eproperties of the service.
		/// </summary>
		/// <returns>The string concationation of the service's properties</returns>
		public override String ToString()
		{
			return name + ":" + executable + " " + parameterList;
		}
	}
}
