/*
 * RunAsService, the service to run non-service applications as a service
 *
 * Distributable under Academic Free License Version 1.2
 * See http://www.opensource.org/licenses/academic.php
 */

using log4net;

using System;
using System.Collections;
using System.Configuration;
using System.Xml;

namespace nl.dulsoft.windows.service.config
{
	/// <summary>
	/// Contains the configuration information of each application that needs to 
	/// be run as service.
	/// </summary>
	public class ServicesConfig : IEnumerable
	{
		private const string SERVICE_SETTING = "service.settings/service";
		private const string NAME_SECTION = "name";
		private const string EXEC_SECTION = "executable";
		private const string PARAM_SECTION = "parameters";

		private static ILog log = LogManager.GetLogger(typeof(ServicesConfig));

		private ArrayList serviceList = new ArrayList();

		internal ServicesConfig()
		{
			if (log.IsDebugEnabled)
			{
				log.Debug("cons");
			}
		}

		internal void Add(XmlNode section) 
		{
			if (log.IsDebugEnabled)
			{
				log.Debug("+Add");
			}

			Service service = null;

			try
			{
				string name = getSectionText(section, NAME_SECTION);
				string executable = section[EXEC_SECTION].InnerText;
				string parameterList = getSectionText(section, PARAM_SECTION);

				service = new Service(name, executable, parameterList);
				serviceList.Add(service);
			}
			catch (NullReferenceException e)
			{
				log.Error("Error in configuration. Is mandatory element <" + EXEC_SECTION + "> set?", e);
			}

			if (log.IsDebugEnabled)
			{
				log.Debug("-Add(" + service + ")");
			}
		}

		private String getSectionText(XmlNode section, String name)
		{
			if (log.IsDebugEnabled)
			{
				log.Debug("+getSectionText(" + section + ", " + name + ")");
			}

			XmlElement elm = section[name];
			String result;

			if (null != elm)
			{
				result = elm.InnerText;
			}
			else
			{
				result = "";
			}

			if (log.IsDebugEnabled)
			{
				log.Debug("-getSectionText:" + result);
			}

			return result;
		}

		/// <summary>
		/// Retrieves the configuration settings as described in the application 
		/// configuration file.
		/// </summary>
		/// <returns>The configuration settings</returns>
		public static ServicesConfig getConfig() 
		{
			if (log.IsDebugEnabled)
			{
				log.Debug("+getConfig");
			}

			ServicesConfig config = (ServicesConfig) ConfigurationManager.GetSection(SERVICE_SETTING);

			if (log.IsDebugEnabled)
			{
				log.Debug("-getConfig");
			}

			return config;
		}
		#region IEnumerable Members

		/// <summary>
		/// Returns an enumerator capable of enumrating over the configuration settings
		/// </summary>
		/// <returns>The enumerator as supplied by the serives List.</returns>
		public IEnumerator GetEnumerator()
		{
			return serviceList.GetEnumerator();
		}

		#endregion

		/// <summary>
		/// Get's the total number of services in the configuration.
		/// </summary>
		public int Count
		{
			get
			{
				return serviceList.Count;
			}
		}
	}
}
