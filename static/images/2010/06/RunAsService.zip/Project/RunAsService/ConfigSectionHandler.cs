/*
 * RunAsService, the service to run non-service applications as a service
 *
 * Distributable under Academic Free License Version 1.2
 * See http://www.opensource.org/licenses/academic.php
 */

using log4net;

using System;
using System.Configuration;
using System.Xml;

namespace nl.dulsoft.windows.service.config
{
	/// <summary>
	/// Processes the config section in the application.config file.
	/// </summary>
	public class ConfigSectionHandler : IConfigurationSectionHandler
	{
		private static ILog log = LogManager.GetLogger(typeof(ConfigSectionHandler));
		private ServicesConfig config = new ServicesConfig();

		/// <summary>
		/// Processes one single custom section in the application configuration file.
		/// </summary>
		/// <param name="parent"></param>
		/// <param name="context"></param>
		/// <param name="section">The section in XmlNode format</param>
		/// <returns>The resulting configuration object</returns>
		public object Create(object parent, 
			object context, 
			XmlNode section) 
		{
			if (log.IsDebugEnabled)
			{
				log.Debug("+Create(" + section.ToString() + ")");
			}

			config.Add(section);

			if (log.IsDebugEnabled)
			{
				log.Debug("-Create");
			}

			return config;
		}
	}
}
